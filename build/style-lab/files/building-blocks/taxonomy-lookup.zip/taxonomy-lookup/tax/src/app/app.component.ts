import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './tax/src/app/app.component.html',
  styleUrls: ['./tax/src/app/app.component.css']
})
export class AppComponent {
  title = 'Taxonomy Lookup';
}
