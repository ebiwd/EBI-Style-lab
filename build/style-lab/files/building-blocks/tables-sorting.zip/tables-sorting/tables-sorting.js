window.addEventListener('load',function() {
  $(document).ready(function() {
      $("#table-sort-demo").tablesorter();
  });
});
