// Moved to: 
// https://www.ebi.ac.uk/web_guidelines/EBI-Framework/v1.3/js/elixirBanner.js
